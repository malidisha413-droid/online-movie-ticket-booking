package com.disha.movieticket.controller;

import com.disha.movieticket.model.Booking;
import com.disha.movieticket.model.Movie;
import com.disha.movieticket.repository.BookingRepository;
import com.disha.movieticket.repository.MovieRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:3000")
public class BookingController {
    private final BookingRepository bookingRepository;
    private final MovieRepository movieRepository;

    public BookingController(BookingRepository bookingRepository, MovieRepository movieRepository) {
        this.bookingRepository = bookingRepository;
        this.movieRepository = movieRepository;
    }

    @GetMapping
    public List<Booking> getBookings() {
        return bookingRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Booking createBooking(@Valid @RequestBody BookingRequest request) {
        Movie movie = movieRepository.findById(request.movieId())
                .orElseThrow(() -> new IllegalArgumentException("Movie not found"));
        Booking booking = new Booking(request.customerName(), movie, request.seats());
        return bookingRepository.save(booking);
    }

    public record BookingRequest(String customerName, Long movieId, int seats) {}
}
