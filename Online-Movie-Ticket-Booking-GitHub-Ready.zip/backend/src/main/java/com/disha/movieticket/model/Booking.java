package com.disha.movieticket.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "bookings")
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String customerName;

    @ManyToOne(optional = false)
    private Movie movie;

    @Min(1)
    private int seats;

    private String status;

    public Booking() {}

    public Booking(String customerName, Movie movie, int seats) {
        this.customerName = customerName;
        this.movie = movie;
        this.seats = seats;
        this.status = "CONFIRMED";
    }

    public Long getId() { return id; }
    public String getCustomerName() { return customerName; }
    public Movie getMovie() { return movie; }
    public int getSeats() { return seats; }
    public String getStatus() { return status; }

    public void setId(Long id) { this.id = id; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public void setMovie(Movie movie) { this.movie = movie; }
    public void setSeats(int seats) { this.seats = seats; }
    public void setStatus(String status) { this.status = status; }
}
