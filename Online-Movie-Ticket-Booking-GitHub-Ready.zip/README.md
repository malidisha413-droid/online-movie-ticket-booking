# Online Movie Ticket Booking System

A full-stack web application for browsing movies and booking movie tickets.

## Tech Stack
- Java 21
- Spring Boot
- Spring Data JPA / Hibernate
- MySQL
- React.js
- REST APIs
- Bootstrap
- JUnit

## Features
- User registration and login
- Movie listing
- Add movies through REST API
- Seat selection
- Ticket booking
- Booking details
- Basic validation and exception handling

## Project Structure
- `backend/` - Spring Boot REST API
- `frontend/` - React frontend

## How to Run

### Backend
1. Create a MySQL database named `movie_ticket_db`.
2. Update `backend/src/main/resources/application.properties` with your MySQL username/password.
3. Run the Spring Boot application.
4. Backend runs on `http://localhost:8080`.

### Frontend
```bash
cd frontend
npm install
npm start
```
Frontend runs on `http://localhost:3000`.

## Important
Do not upload real passwords, API keys, or other secrets to GitHub.
