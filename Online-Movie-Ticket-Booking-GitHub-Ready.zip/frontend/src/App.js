import React, { useEffect, useState } from "react";

const API = "http://localhost:8080/api";

function App() {
  const [movies, setMovies] = useState([]);
  const [name, setName] = useState("");
  const [movieId, setMovieId] = useState("");
  const [seats, setSeats] = useState(1);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch(`${API}/movies`)
      .then((res) => res.json())
      .then(setMovies)
      .catch(() => setMessage("Start the Spring Boot backend first."));
  }, []);

  const bookTicket = async (e) => {
    e.preventDefault();
    if (!movieId || !name.trim()) {
      setMessage("Please enter your name and select a movie.");
      return;
    }

    const response = await fetch(`${API}/bookings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customerName: name,
        movieId: Number(movieId),
        seats: Number(seats)
      })
    });

    if (response.ok) {
      const booking = await response.json();
      setMessage(`Booking confirmed. Booking ID: ${booking.id}`);
      setName("");
      setMovieId("");
      setSeats(1);
    } else {
      setMessage("Booking failed. Please try again.");
    }
  };

  return (
    <div className="container">
      <h1>Online Movie Ticket Booking</h1>

      <section>
        <h2>Available Movies</h2>
        {movies.length === 0 ? (
          <p>No movies available. Add one using the POST /api/movies API.</p>
        ) : (
          <div className="movies">
            {movies.map((movie) => (
              <div className="card" key={movie.id}>
                <h3>{movie.title}</h3>
                <p>{movie.genre} • {movie.language}</p>
                <p>{movie.durationMinutes} minutes</p>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="booking">
        <h2>Book Tickets</h2>
        <form onSubmit={bookTicket}>
          <input
            placeholder="Customer name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <select value={movieId} onChange={(e) => setMovieId(e.target.value)}>
            <option value="">Select movie</option>
            {movies.map((movie) => (
              <option key={movie.id} value={movie.id}>{movie.title}</option>
            ))}
          </select>
          <input
            type="number"
            min="1"
            value={seats}
            onChange={(e) => setSeats(e.target.value)}
          />
          <button type="submit">Book Ticket</button>
        </form>
        {message && <p className="message">{message}</p>}
      </section>
    </div>
  );
}

export default App;
